"""
BM25 Fusion package initialization.
"""

from .core import *

__all__ = ["BM25"]
__version__ = "0.1.4"
